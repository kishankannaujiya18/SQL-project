\c onlinebookstore;

-- Create Table
DROP TABLE IF EXISTS Books;
CREATE TABLE Books (
	Book_id SERIAL PRIMARY KEY,
	Title VARCHAR(100),
	Author VARCHAR(100),
	Genre VARCHAR(50),
	Published_year INT,
	Price NUMERIC (10,2),
	Stock INT
);

DROP TABLE IF EXISTS Customers;
CREATE TABLE Customers (
	Customer_id SERIAL PRIMARY KEY,
	Name VARCHAR(100),
	Email VARCHAR(100),
	Phone VARCHAR(50),
	city VARCHAR(100),
	country VARCHAR(100)
);

DROP TABLE IF EXISTS Orders;
CREATE TABLE Orders(
	Order_id SERIAL PRIMARY KEY,
	Customer_id INT REFERENCES Customers (Customer_id),
	Book_id INT REFERENCES Books (Book_id),
	order_date DATE,
	Quantity INT,
	Total_Amount NUMERIC (10,2)
);

SELECT * FROM Books;
SELECT * FROM Customers;
SELECT * FROM Orders;

-- import data into tables
COPY Books(book_id, title, author, genre, published_year, price, stock)
FROM '‪'
CSV HEADER;

--1)Retrieve all books in the "fiction" genre:
SELECT * FROM Books
WHERE genre='fiction';

--2) Find book published after the year 1950:
SELECT * FROM Books
WHERE Published_year>1950;

--3) List all customer from the canada:
SELECT * FROM Customers
WHERE Country='canada';

--4) Show order placed in nov 2025:
SELECT * FROM Orders
WHERE order_date BETWEEN '2023-11-01' AND '2023-11-30'; 

--5) retrieve the total stock of books available.
SELECT SUM(stock) AS total_stock
FROM Books;

--6) find the detail of the most expensive books.
SELECT * FROM Books
ORDER BY price DESC
LIMIT 5;

--7) show all customer who orederd more than 1 quantity of a book.
SELECT * FROM orders
WHERE quantity>1;

--8) retrieve all orders where the total amount exceeds $20:
SELECT * FROM orders
WHERE total_amount>20;

--9) last all genre available in the books table:
SELECT DISTINCT genre FROM Books;

--10) find the book with the lowest stocks:
SELECT * FROM Books ORDER BY stock DESC;

--11) Calculate the total revenue generated from all orders:
SELECT SUM(total_amount) AS revenue
from orders;

--Advance Query
--1) Retrieve the total number of books sold for each genre:
SELECT * FROM oreders;
SELECT b.Genre, SUM(o.Quantity) AS total_Books_sold
FROM Orders o
JOIN Books b ON o.book_id = b.book_id
GROUP BY b.Genre;

--2) find the average price of books in the "fantasy" genre:
SELECT AVG(price) AS Average_price
FROM Books
WHERE Genre = 'Fantasy';

--3) list custtomer's who have placed at least 2 order:
SELECT o.customer_id, COUNT (order_id) AS order_count
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
GROUP BY o.customer_id, c.name
HAVING COUNT (order_id)>2;

--4) find the most frequency ordered books:
SELECT o.Book_id, b.title, COUNT(o.order_id) AS order_count
FROM orders o
JOIN books b ON o.book_id = b.book_id
GROUP BY o.book_id, b.title
ORDER BY order_count DESC LIMIT 5;

--5) show the top three most expensive books of 'fantasy' genre:
SELECT * FROM books
WHERE Genre = 'Fantasy'
ORDER BY price DESC LIMIT 5;

--6) retrieve the total quantity of books sold by each author:
SELECT b.author, SUM(o.Quantity) AS total_book_sold
FROM orders o
JOIN books b  ON o.book_id = b.book_id
GROUP BY b.author;

--7) list the cities where customer who spent over $ 30 are located:
SELECT DISTINCT c.city, total_amount
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
WHERE o.total_amount>30;

--8) find the customer who spent the most on orders:
SELECT c.customer_id, c.name, SUM(o.total_amount) AS total_spent
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
GROUP BY c.customer_id, c.name
ORDER BY total_spent DESC LIMIT 10;

--9) calculate the stock remaining after fulfilling all orders:
SELECT b.book_id, b.title, b.stock, COALESCE(SUM(o.Quantity),0) AS order_Quantity,
b.stock - COALESCE(SUM(o.quantity),0) AS remaining_Quantity
FROM books b
LEFT JOIN orders o ON b.book_id = o.book_id
GROUP BY b.book_id 
ORDER BY b.book_id;
